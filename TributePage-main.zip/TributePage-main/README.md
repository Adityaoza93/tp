# Tribute Page
<p>A tribute page is a webpage based on a person who inspired us in our life. This page contain a webpage of <strong>Dr. Norman Borlaug</strong>. This page is <b>Responsive Web Design Projects</b> at <strong>FreeCodeCamp</strong>.</p>
<p>To see the webpage, <a href="https://richardgery.github.io/TributePage/">visit our website</a>.</p>

